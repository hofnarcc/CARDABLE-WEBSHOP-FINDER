1. RUN Cardable Webshop Finder.exe

Optional:
Get results via a Telegram bot.

Required:
- Load the keywords.txt
- Load the payment_providers.txt

Click on start!

NOTE: Leave the tool running, it could take hours depending on the amount of keywords and payment providers you are searching.